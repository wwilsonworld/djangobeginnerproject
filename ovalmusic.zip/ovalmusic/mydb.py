import mysql.connector

database = mysql.connector.connect(
    host = 'localhost',
    user = 'root' ,
    passwd = 'Wilson1234**',
    auth_plugin = 'mysql_native_password'

)

cursorObject = database.cursor()

cursorObject.execute("CREATE DATABASE ovalmusic")

print("created")
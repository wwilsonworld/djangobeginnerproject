from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from .forms import SignUpForm, AddRecordForm
from .models import Music

def signin(request):

    #chck if users is loggin in
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        #authenticate
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            messages.success(request, " Logged in")
            return redirect('home') 
        else:
            messages.success(request," there was an error loggin in")
            return redirect('signin')
    else:
        return render(request,'signin.html',{})

def signup(request):

    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
             #authenticate and login
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username,password=password)
            login(request, user)
            messages.success(request,"Registered succesfuly")
            return redirect('home')
    else:
        form = SignUpForm()
        return render(request, 'signup.html',{'form': form},)
    return render(request, 'signup.html',{'form': form})
def home(request):
   
    if request.user.is_authenticated:
        music = Music.objects.all()
        return render(request, 'home.html', {'music':music})
    else:
        messages.success(request,"You must be logged in" )
        return redirect ('signin')
    


def saved(request):
    return render(request, 'saved.html', {})

def logout_page(request):
    logout(request)
    messages.success(request,"you have been logged out")
    return redirect('signin')

def edit_song(request,pk):
    if request.user.is_authenticated:
        m_record = Music.objects.get(id=pk)
        return render(request, 'edit.html', {'m_record': m_record})
    else:
        messages.success(request,"you must be logged in")
        return redirect('signin')

def delete_record(request,pk):
    delete_it = Music.objects.get(id=pk)
    delete_it.delete()
    messages.success(request, " Record deleted succesfully")
    return redirect('home')

def add_page(request):
    form = AddRecordForm(request.POST or None,request.FILES or None)
    if request.user.is_authenticated:
        if request.method == 'POST':
            if form.is_valid():
                record = form.save()
                return redirect('home')
        return render(request,'add.html',{'form':form})
    else:
        messages.success(request, " You must be logged in")
        return redirect('home')


def update_record(request,pk):
    c = Music.objects.get(id=pk)
    form = AddRecordForm(request.POST or None,request.FILES or None,instance=c)
    if form.is_valid():
        form.save()
        messages.success(request,"Record updated succesfully")
        return redirect('home')
    return render(request,'update.html',{'form':form})
    




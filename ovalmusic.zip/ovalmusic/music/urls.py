from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('signin/', views.signin, name='signin'),
    path('signup/',views.signup, name='signup'),
    path('home/', views.home, name='home'),
    path('saved/', views.saved, name='saved'),
    path('logout/',views.logout_page,name='logout'),
    path('edit/<int:pk>', views.edit_song, name='edit'),
    path('deletes/<int:pk>',views.delete_record, name='deletes'),
    path('add_record/',views.add_page,name='add_record'),
    path('updaterecord/<int:pk>',views.update_record,name='update_record')
    
    
]


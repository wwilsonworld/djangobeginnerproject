from django.db import models


class Music(models.Model):
    created_at = models.DateTimeField(auto_now_add = True)
    song = models.FileField( storage=None, max_length=100)
    songtitle = models.CharField(max_length=50)
    artistname = models.CharField(max_length=50)
    featured = models.CharField(max_length=50,blank=True, null=True)

    def __str__(self):
        return(f"{self.songtitle} {self.artistname}")


from django.shortcuts import render,redirect
import talib
import pandas as pd
import yfinance as yf
import MetaTrader5 as mt5
import time

#if account = account selected
#if option = selected option then check symbol
#if symbol then get function for robot and pass in symbol and account for the selected option and the symbol
def home(request):

   

    signal = []

    if not mt5.initialize(login=5039831730, server="MetaQuotes-Demo",password="_0JaOrXq"):
        
        error = mt5.last_error()
        signal.append(error)
        

        return render(request, 'dashboard.html', {'error': error,})
    
    elif request.method == 'POST':
            
            signal = []
            #first we login into mt5 account

            while mt5.initialize(login=5039831730, server="MetaQuotes-Demo",password="_0JaOrXq"):

                symbol = request.POST.get('symbol')
                print(symbol)
                
                action= request.POST.get('action')
                if action== "SR":
                    print(action)
                elif action == "Breakout":
                    print(action)


            
                #first we get the data
                rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_D1, 0, 10)

                data = pd.DataFrame(rates)

                # we then calculate the resistance and support
                resistance = data['high'].max()
                support = data['low'].min()

                #then we chck for the patterns
                pattern = talib.CDLENGULFING(data['open'], data['high'], data['low'], data['close'])

                condition = pattern[-2:]

                w = 0.001
                price = data['close'].iloc[-1]

                #we check if the pattern is in support or resistance
                if (condition < 0).any() and ((resistance - w < price) & (price < resistance + w)).all():
                    status = "price at resistance"
                    
                elif (condition > 0).any() & ((support - w < price) & (price < support + w)).all():
                    status = "price at support"
                
                else:
                    status = "price in range"

    
                error = mt5.last_error()
                signal.append(status)

                time.sleep(120)

                return render(request,'dashboard.html',{'error':error,'signal':signal})
        
    

    return render(request,'dashboard.html',{'signal':signal})

def strategies(request):
    return render(request,'strategies.html',{})
from django.urls import path
from . import views

urlpatterns = [
    path('home/',views.home,name="home"),
    path('category/',views.category,name="category"),
    path('contact/',views.contact,name="contact"),
    path('listing/',views.listing,name="listing"),
    path('login_user/',views.login_user,name="login_user"),
    path('register_user/',views.register_user,name="register_user"),
    path('logout_user/',views.logout_user,name="logout_user"),
    path('add/',views.add,name="add"),
    path('dash/',views.dash,name="dash"),

]
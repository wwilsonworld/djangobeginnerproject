from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.utils import timezone


class blocks_users(AbstractUser):
    phone = models.CharField(max_length=20)
    groups = models.ManyToManyField(
        Group,
        related_name='blocksuser_groups',
        blank=True
    )

    user_permissions = models.ManyToManyField(
        Permission,
        related_name='blocksuser_permissions',
        blank=True
    )
    
class Property(models.Model):
    owner = models.ForeignKey(blocks_users, on_delete=models.CASCADE)
    title = models.CharField(max_length=150,default="")
    location = models.CharField(max_length=200)
    price = models.IntegerField()
    description = models.TextField(default="")
    bedrooms = models.IntegerField()
    baths = models.IntegerField()
    image = models.ImageField(upload_to='properties/')
    views = models.IntegerField(default=0)
    visits_count = models.IntegerField(default=0)
    interested = models.IntegerField(default=0)
    sqrft =  models.IntegerField()
    status = models.CharField(max_length=20, default="Available")
    date_posted = models.DateTimeField(default=timezone.now)



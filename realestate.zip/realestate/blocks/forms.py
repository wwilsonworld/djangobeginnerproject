from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Property,blocks_users

class login_form(forms.Form):
    username = forms.CharField(max_length=254)
    password = forms.CharField()

  

class registration_form(UserCreationForm): 
    email = forms.EmailField()
    phone = forms.IntegerField()

    class Meta:
        model = blocks_users
        fields = ("username","email","phone", "password1","password2")

class PropertyForm(forms.ModelForm):
    class Meta:
        model = Property
        fields = ["title","description","views","visits_count","interested","status","sqrft", "bedrooms", "baths","price", "location", "image"]
